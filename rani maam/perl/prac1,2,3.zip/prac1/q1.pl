
print("Enter your DNA seq: ");$seq = <stdin>;

print("This is the DNA seq you entered: $seq");