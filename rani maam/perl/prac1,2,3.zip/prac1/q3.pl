
%codons = (1 => AUG, 2 => AAA, 3 => UUU, 4 => AGG);

print("codon 1 is $codons{1}\n");
print("codon 2 is $codons{2}\n");
print("codon 3 is $codons{3}\n");
print("codon 4 is $codons{4}\n");