

$num = 5;for($i=0;$i<6;$i++){
	for($j=$num;$j>0;$j--){
		print("A");
	}
	print("\n");
	$num--;
}