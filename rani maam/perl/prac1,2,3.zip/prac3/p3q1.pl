print("Enter 1st Number: ");
$num1 = <stdin>;
print("Enter 2nd Number: ");
$num2 = <stdin>;
print("Enter 1st String: ");
$string1 = <stdin>;
print("Enter 2nd String: ");
$string2 = <stdin>;

print("\nExecuting arithmetic operators...\n");

print("Addition: ");
print($num1+$num2);
print("\n");

print("Subtraction: ");
print($num1-$num2);
print("\n");

print("Division: ");
print($num/$num2);
print("\n");

print("Multiplication: ");
print($num*$num2);
print("\n");

print("Modulo ");
print($num%$num2);
print("\n");

print("Exponent ");
print($num**$num2);
print("\n");

print("\nExecuting miscellenous...\n");

print("Concatenate: ");
print("$string1.$string2");
print("\n");

print("Repetition ");
print("$string1"x3);
print("\n");

print("Range ");
print($num1..$num2);
print("\n");

print("Autoincrement(num1): ");
print($num1++);
print("\n");

print("Autodecrement(num1) ");
print($num1--);
print("\n");