print("Enter 1st String: ");
$string1 = <stdin>;

print("Enter 2nd String: ");
$string2 = <stdin>;

if($string1 eq $string2){
	print("\nStrings are equal\n");
}else{
	print("\nStrings are not equal\n");
}