@strings = ("iuasdh", "awdui", "hawuid", "aoiudh", "woiu", "aid9", "woh");

print($strings[3..5]);