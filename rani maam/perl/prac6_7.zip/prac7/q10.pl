# Write a Perl program accept an RNA sequence and display the index number of an entered character

