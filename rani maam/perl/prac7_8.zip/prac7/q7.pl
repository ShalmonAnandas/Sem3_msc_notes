# Write a Perl program to demonstrate substr() function

$string = "This is Department of bioinformatics";

$sub_string =substr($string, 5, 10);

print("$string\n");
print("$sub_string\n");