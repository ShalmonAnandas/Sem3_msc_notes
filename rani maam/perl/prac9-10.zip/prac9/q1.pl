use Square;

$obj = new Square();

$obj -> area();
