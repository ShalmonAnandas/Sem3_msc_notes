use Student;

$obj = new Student('Shalmon','92');

$obj -> display();