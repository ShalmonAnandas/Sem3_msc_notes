@sequence;

print("Enter the first RNA sequence: ");
$sequence[0] = <stdin>;

print("Enter the Second RNA sequence: ");
$sequence[1] = <stdin>;

print("Enter the Third RNA sequence: ");
$sequence[2] = <stdin>;

print("Enter the fourth RNA sequence: ");
$sequence[3] = <stdin>;

print("Enter the fifth RNA sequence: ");
$sequence[4] = <stdin>;

print("The sequences you entered are: \n");

print("Sequence 1: $sequence[0]");
print("Sequence 2: $sequence[1]");
print("Sequence 3: $sequence[2]");
print("Sequence 4: $sequence[3]");
print("Sequence 5: $sequence[4]");