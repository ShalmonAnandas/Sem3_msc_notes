print("Enter a number: ");

$num = <stdin>;

if($num % 2 == 0){
	print("Number is Even\n");
}else{
	print("Number is Odd\n");
}