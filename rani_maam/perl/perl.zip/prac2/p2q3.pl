
print("Enter a number: ");

$number = <stdin>;

if($number % 2 == 0){
	print("Number is even\n");
}else{
	print("Number is odd\n");
}