@strings = ("ATGU", "ATTG", "ATCG", "TGAC", "TCGA", "TACG", "GCTA");

print("@strings[3..5]");