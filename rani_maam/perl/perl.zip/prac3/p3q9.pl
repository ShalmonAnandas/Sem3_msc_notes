
@arr = (0..9);
print("Complete array @arr\n");

@replacement = splice(@arr, 3, 4, a..d);
print("Added Elements @arr\n");