
print("Enter a number: ");
$num = <stdin>;

$ref_num = \$num;

print("Number entered and stored in Reference is ",${$ref_num},"\n");