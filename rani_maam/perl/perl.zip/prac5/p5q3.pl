
%subjects = (1=>"Biology", 2=>"Zoology", 3=>"Mathematics", 4=>"Physics", 5=>"Chemistry");

$ref_hash = \%subjects;

print("Hash entered and stored in Refenrence is ",%{$ref_hash},"\n");