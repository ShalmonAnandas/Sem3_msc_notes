
use feature 'state';
state $static_number = 70;		
print("Printing Static variable $static_number\n");
print("Trying to change value of static variable from 70 to 100\n");

$static_number = "shalmon";
print("Printing Static variable after changing $static_number\n");
