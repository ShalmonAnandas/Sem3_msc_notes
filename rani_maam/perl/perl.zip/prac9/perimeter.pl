use Perimeter;

$obj = new Perimeter();

$obj->sq_peri;
$obj->tri_peri;