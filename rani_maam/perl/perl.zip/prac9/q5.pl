use Employee;

$obj = new Employee();

$obj -> display();